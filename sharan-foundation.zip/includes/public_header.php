<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/i18n.php';
$flash = flash_get();
$current_page = $current_page ?? '';
$page_title = $page_title ?? 'Sharan Foundation';
$page_desc = $page_desc ?? 'A Christian charity serving India & UK through education, shelter and faith.';
$BU = BASE_URL;
$LANG = current_lang();
$langs = available_languages();
?><!DOCTYPE html>
<html lang="<?= e($LANG) ?>">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title><?= e($page_title) ?> | Sharan Foundation</title>
<meta name="description" content="<?= e($page_desc) ?>" />
<link rel="icon" href="<?= $BU ?>images/logo.png" />
<link rel="stylesheet" href="<?= $BU ?>css/style.css" />
<?php if ($LANG === 'hi'): ?>
<style>body{font-family:'Noto Sans Devanagari','Segoe UI',sans-serif}</style>
<?php endif; ?>
<style>
  /* Language switcher */
  .lang-switch{display:inline-flex;align-items:center;gap:.3rem;margin-left:1rem;background:rgba(255,255,255,.1);padding:.15rem .15rem;border-radius:50px;font-size:.8rem}
  .lang-switch a{padding:.2rem .7rem;color:#fff;opacity:.7;border-radius:50px;transition:.2s;text-decoration:none}
  .lang-switch a:hover{opacity:1}
  .lang-switch a.active{background:var(--accent);color:#fff;opacity:1;font-weight:600}
  @media(max-width:600px){.lang-switch{margin-left:.4rem;font-size:.72rem}.lang-switch a{padding:.15rem .5rem}}
</style>
<?php if (!empty($extra_head)) echo $extra_head; ?>
</head>
<body>

<!-- TOP BAR -->
<div class="topbar">
  <div class="container">
    <div>📧 <?= e(get_setting('email_in','contact@sharanfoundation.org')) ?> &nbsp;|&nbsp; 📞 <?= e(get_setting('phone_in','+91 98765 43210')) ?> (IN) &nbsp;|&nbsp; <?= e(get_setting('phone_uk','+44 20 1234 5678')) ?> (UK)</div>
    <div style="display:flex;align-items:center;flex-wrap:wrap">
      <a href="<?= $BU ?>pages/volunteer.php"><?= e(t('nav_volunteer')) ?></a>
      <a href="<?= $BU ?>pages/partner.php"><?= e(t('nav_partner')) ?></a>
      <div class="lang-switch" title="Language / भाषा">
        <?php foreach ($langs as $code => $info): ?>
          <a href="<?= e(lang_url($code)) ?>" class="<?= $LANG===$code?'active':'' ?>" title="<?= e($info['name']) ?>"><?= e($info['flag']) ?> <?= e($code === 'hi' ? 'हि' : 'EN') ?></a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- NAVBAR -->
<header class="nav">
  <div class="nav-inner">
    <a href="<?= $BU ?>" class="logo">
      <div class="logo-mark"><img src="<?= $BU ?>images/logo.png" alt="Sharan Foundation"></div>
      <div>Sharan Foundation<small><?= e(t('site_tagline')) ?></small></div>
    </a>
    <nav>
      <button class="menu-toggle">☰</button>
      <ul id="navlist">
        <li><a href="<?= $BU ?>" class="<?= $current_page==='home'?'active':'' ?>"><?= e(t('nav_home')) ?></a></li>
        <li><a href="<?= $BU ?>pages/about.php" class="<?= $current_page==='about'?'active':'' ?>"><?= e(t('nav_about')) ?></a></li>
        <li><a href="<?= $BU ?>pages/programs.php" class="<?= $current_page==='programs'?'active':'' ?>"><?= e(t('nav_programs')) ?></a></li>
        <li><a href="<?= $BU ?>pages/projects.php" class="<?= $current_page==='projects'?'active':'' ?>"><?= e(t('nav_projects')) ?></a></li>
        <li><a href="<?= $BU ?>pages/fundraisers.php" class="<?= $current_page==='fundraisers'?'active':'' ?>"><?= e(t('nav_fundraisers')) ?></a></li>
        <li><a href="<?= $BU ?>pages/gallery.php" class="<?= $current_page==='gallery'?'active':'' ?>"><?= e(t('nav_gallery')) ?></a></li>
        <li><a href="<?= $BU ?>pages/blog.php" class="<?= $current_page==='blog'?'active':'' ?>"><?= e(t('nav_blog')) ?></a></li>
        <li><a href="<?= $BU ?>pages/contact.php" class="<?= $current_page==='contact'?'active':'' ?>"><?= e(t('nav_contact')) ?></a></li>
        <li><a href="<?= $BU ?>pages/donate.php" class="btn btn-primary"><?= e(t('nav_donate')) ?> ♥</a></li>
      </ul>
    </nav>
  </div>
</header>
